import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        /*4 - Faça um programa que leia 5 números e informe a soma e a média dos números */

        int soma = 0, num, media;
        Scanner sc = new Scanner(System.in);

        for(int i = 1; i <= 5; i++) {
            System.out.print("Escreva o " + i + "o " + "número: ");
            num = sc.nextInt();
            
            soma += num;
            System.out.println("Soma: " + soma);
            
        }
        media = soma / 5;
        System.out.print("Média: " + media);
        sc.close();


    }
}
