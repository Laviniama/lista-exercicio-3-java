import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        
        /*1 - Faça um programa que peça uma nota, entre zero e dez. mostre uma mensagem 
        caso o valor seja inválido e continue pedindo até que o usuário informe um valor 
        válido. */

        Scanner sc = new Scanner(System.in);
        int nota;
        
        //======= Faz a repetição da mensagem quando a nota é menor que 0 OU maior que 10 =======
       do{
            
            
            //======= pede a nota =======
        System.out.print("Escreva uma nota de 0 a 10: ");
        nota = sc.nextInt();


        } while (nota < 0 || nota > 10);
     
        System.out.print("Nota: " + nota);
        sc.close();
    }
}
