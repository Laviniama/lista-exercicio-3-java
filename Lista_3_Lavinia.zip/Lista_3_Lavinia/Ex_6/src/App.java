import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        /*6 - Faça um programa que receba dois números inteiros e gere os números inteiros 
        que estão no intervalo compreendido por eles. */

        int n, m;
        Scanner sc = new Scanner(System.in);

        System.out.print("Insira o menor numero: ");
        m = sc.nextInt();
        System.out.print("Insira o maior numero: ");
        n = sc.nextInt();
                
        for(int i = m + 1; i < n; i++ ) {
            
            System.out.print(i + ", ");
        }
    }
}
