import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        /*3 - Faça um programa que leia e valide as seguintes informações:
        Nome: maior que 3 caracteres;
        Idade: entre 0 e 150;
        Salário: maior que zero;
        Sexo: 'f' ou 'm';
        Estado Civil: 's', 'c', 'v', 'd'; */

        Scanner sc = new Scanner(System.in);
        String nome = "a", sexo, civil;
        int idade, salario, tamnome;

        //======= ESTRUTURA DE REPETIÇÃO =======
        do {

            //======= ENTRADA DE DADOS =======
            System.out.print("Nome: ");
            nome = sc.next();
            tamnome = nome.length();
            System.out.print("Idade: ");
            idade = sc.nextInt();
            System.out.print("Salario: ");
            salario = sc.nextInt();
            System.out.print("Sexo: (m, f)");
            sexo = sc.next();
            System.out.print("Estado Civil (s, c, v, d): ");
            civil = sc.next();

            //======= MENSAGEM DE ERRO =======
            if (tamnome < 3){
                System.out.println("Nome deve ter mais que 3 caracteres: ");
            }
            if (idade < 0 || idade >150){
                System.out.println("Idade inválida");
            }
            if (salario <= 0){
                System.out.println("Salario deve ser maior que 0");
            }
            if (!sexo.equals("m") && sexo !="f"){
                System.out.println("Sexo inválido (aceitamos apenas letras minusculas)");
            }
            if (!civil.equals("s") && !civil.equals("c") && !civil.equals("v") && !civil.equals("d")){
                System.out.println("Estado Civil Inválido (aceitamos apenas letras minusculas)");
            }

        }while(tamnome < 3 || idade < 0 || idade >150 || salario <= 0 || !sexo.equals("m") && sexo !="f" || !civil.equals("s") && !civil.equals("c") && !civil.equals("v") && !civil.equals("d"));

        System.out.println("USUARIO CADASTRADO");
    }
}
