import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        
        /* 7 - Faça um programa que peça 10 números inteiros, calcule e mostre a quantidade 
        de números pares e a quantidade de números impares*/

        int contpar = 0, contimpar = 0, contqtd = 1, num;
        Scanner sc = new Scanner(System.in);

        while(contqtd != 11) {
            System.out.print("Digite o " + contqtd + "o número: ");
            num = sc.nextInt();
            
            if (num % 2 == 0) {
                contpar++;
            }
            else {
                contimpar++;
            }
            
            contqtd++;
        }
        
        System.out.println("QNT Par: " + contpar);
        System.out.println("QNT Impar: " + contimpar);
        
    }
}
