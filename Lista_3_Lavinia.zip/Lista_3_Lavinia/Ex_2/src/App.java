import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        /*2 - Faça um programa que leia um nome de usuario e a sua senha e não aceite a 
        senha igual ao nome do usuário, mostrando uma mensagem de erro e voltando a 
        pedir as informações */

        Scanner sc = new Scanner(System.in);
        String user, senha;

        //====== ESTRUTURA DE REPETIÇÃO =======
        do{ 

            //======= ENTRADA DE DADOS =======
            System.out.print("Digite o Nome de Usuário: ");
            user = sc.next();
            System.out.print("Digite a Senha: ");
            senha = sc.next();

            //======= MENSAGEM DE ERRO =======
            if (user.equals(senha)){
                System.out.println("O NOME DE USUÁRIO NÃO PODE SER IGUAL A SENHA");
            }


        }while (user.equals(senha));

        //======= MENSAGEM DE SUCESSO =======
        System.out.print("USUÁRIO CADASTRADO COM SUCESSO!!");
    }
}
